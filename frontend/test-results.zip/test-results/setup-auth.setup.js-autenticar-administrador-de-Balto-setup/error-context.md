# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: setup\auth.setup.js >> autenticar administrador de Balto
- Location: tests\setup\auth.setup.js:13:6

# Error details

```
Error: [Playwright cleanup] inicio de corrida: HTTP 500. No se pudo completar la limpieza automática del testing.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - button [ref=e6] [cursor=pointer]:
      - img "Logo de Balto" [ref=e7]
    - generic [ref=e8]:
      - generic [ref=e9]: Dashboard
      - button "Cambiar a modo claro" [ref=e10] [cursor=pointer]
      - button "Ir a Configuración" [ref=e13] [cursor=pointer]
      - button "Abrir perfil" [ref=e16] [cursor=pointer]:
        - img "Logo icono de la empresa" [ref=e17]
      - button "Cerrar sesión" [ref=e18] [cursor=pointer]
  - complementary [ref=e21]:
    - button [ref=e22] [cursor=pointer]:
      - generic:
        - generic: Contable
        - generic: Panel
    - navigation [ref=e26]:
      - button "Dashboard" [ref=e28] [cursor=pointer]
      - generic [ref=e33]:
        - button "Movimientos" [ref=e34] [cursor=pointer]
        - generic:
          - button "Ventas"
          - button "Compras"
          - button "Recibo"
          - button "Orden de Pago"
          - button "Otros Ingresos"
          - button "Otros Egresos"
          - button "Presupuestos"
      - button "Flujo de Caja" [ref=e40] [cursor=pointer]
      - generic [ref=e45]:
        - button "Cuentas Corrientes" [ref=e46] [cursor=pointer]
        - generic:
          - button "Clientes"
          - button "Proveedores"
      - button "Stock" [ref=e52] [cursor=pointer]
      - generic [ref=e57]:
        - button "Servicios" [ref=e58] [cursor=pointer]
        - generic:
          - button "Servicios"
          - button "Inventario e insumos"
      - generic [ref=e63]:
        - button "Contabilidad" [ref=e64] [cursor=pointer]
        - generic:
          - button "IVA Ventas"
          - button "IVA Compras"
      - generic [ref=e69]:
        - button "Cheques" [ref=e70] [cursor=pointer]
        - generic:
          - button "Cheques en Cartera"
          - button "Flujo de Cheques"
          - button "Echeqs en Cartera"
          - button "Flujo de Echeqs"
      - button "Análisis Financiero" [ref=e76] [cursor=pointer]
  - main [ref=e81]:
    - generic [ref=e82]:
      - generic:
        - generic:
          - img "Cargando..."
          - paragraph: Cargando información ..
      - generic [ref=e83]:
        - generic [ref=e84]:
          - generic [ref=e85]:
            - heading "Panel Contable" [level=1] [ref=e86]
            - paragraph [ref=e87]: "Vista general del sistema: caja, movimientos del mes, stock, clientes y proveedores."
          - generic "01/08/2026 / 31/08/2026" [ref=e89]:
            - generic [ref=e92]: Mes actual
            - strong [ref=e93]: Agosto de 2026
        - generic [ref=e94]:
          - article [ref=e95]:
            - generic [ref=e99]:
              - generic [ref=e100]: Caja actual
              - strong [ref=e101]: $ 140,40
              - generic [ref=e102]: Saldo real acumulado
          - article [ref=e103]:
            - generic [ref=e107]:
              - generic [ref=e108]: Ingresos mes actual
              - strong [ref=e109]: "-$ 37,44"
              - generic [ref=e110]: 21 movimientos del mes
          - article [ref=e111]:
            - generic [ref=e115]:
              - generic [ref=e116]: Stock valorizado
              - strong [ref=e117]: $ 0,00
              - generic [ref=e118]: 0 productos activos
          - article [ref=e119]:
            - generic [ref=e123]:
              - generic [ref=e124]: Saldo clientes
              - strong [ref=e125]: $ 0,00
              - generic [ref=e126]: 5 clientes activos
        - generic [ref=e127]:
          - article [ref=e128]:
            - generic [ref=e129]:
              - generic [ref=e130]:
                - heading "Ingresos y egresos del mes actual" [level=2] [ref=e131]
                - paragraph [ref=e132]: Datos calculados desde ventas, compras, otros ingresos, otros egresos y cobros.
              - generic [ref=e133]:
                - generic [ref=e134]: Ingresos
                - generic [ref=e136]: Egresos
            - img "Ingresos y egresos del mes actual" [ref=e138]:
              - generic [ref=e139]:
                - 'generic "20/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e140]': 20/08
                - 'generic "21/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e143]': 21/08
                - 'generic "22/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e146]': 22/08
                - 'generic "23/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e149]': 23/08
                - 'generic "24/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e152]': 24/08
                - 'generic "25/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e155]': 25/08
                - 'generic "26/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e158]': 26/08
                - 'generic "27/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e161]': 27/08
                - 'generic "28/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e164]': 28/08
                - 'generic "29/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e167]': 29/08
                - 'generic "30/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 4" [ref=e170]': 30/08
                - 'generic "31/08 Ingresos: $ 0,00 Egresos: $ 0,00 Movimientos: 0" [ref=e173]': 31/08
          - complementary [ref=e176]:
            - generic [ref=e178]:
              - heading "Indicadores generales" [level=2] [ref=e179]
              - paragraph [ref=e180]: Totales principales del sistema y del mes actual.
            - generic [ref=e181]:
              - generic [ref=e186]:
                - generic [ref=e187]: Resultado del mes
                - strong [ref=e188]: $ 140,40
              - generic [ref=e189]:
                - generic [ref=e194]:
                  - generic [ref=e195]: Ingresos mes
                  - strong [ref=e196]: "-$ 37,44"
                - generic [ref=e201]:
                  - generic [ref=e202]: Egresos mes
                  - strong [ref=e203]: "-$ 177,84"
              - generic [ref=e204]:
                - generic [ref=e209]:
                  - generic [ref=e210]: Proveedores activos
                  - strong [ref=e211]: "3"
                - generic [ref=e216]:
                  - generic [ref=e217]: Saldo proveedores
                  - strong [ref=e218]: $ 0,00
        - generic [ref=e219]:
          - text: Desarrollado por
          - link "3devs.solutions" [ref=e220] [cursor=pointer]:
            - /url: https://3devsnet.com
```

# Test source

```ts
  45  |     sessionKey =
  46  |       map.get('session_key') ||
  47  |       map.get('sessionKey') ||
  48  |       map.get('X-Session') ||
  49  |       map.get('x_session') ||
  50  |       '';
  51  |     token = map.get('token') || map.get('auth_token') || '';
  52  |     if (sessionKey || token) break;
  53  |   }
  54  | 
  55  |   if (!sessionKey && !token) {
  56  |     throw new Error('No se encontró session_key/token para ejecutar la limpieza E2E.');
  57  |   }
  58  | 
  59  |   return { sessionKey, token };
  60  | }
  61  | 
  62  | function authFromStorageFile() {
  63  |   if (!fs.existsSync(AUTH_FILE)) {
  64  |     throw new Error(`No existe el storageState de Playwright: ${AUTH_FILE}`);
  65  |   }
  66  | 
  67  |   const state = JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8'));
  68  |   return authFromStorageState(state);
  69  | }
  70  | 
  71  | function rawHttpRequest(url, { method, headers, payload, timeoutMs = 120_000 }) {
  72  |   return new Promise((resolve, reject) => {
  73  |     const transport = url.protocol === 'https:' ? https : http;
  74  |     const requestHeaders = {
  75  |       ...headers,
  76  |       Connection: 'close',
  77  |       ...(payload !== null
  78  |         ? { 'Content-Length': Buffer.byteLength(payload, 'utf8') }
  79  |         : {}),
  80  |     };
  81  | 
  82  |     const req = transport.request(
  83  |       url,
  84  |       {
  85  |         method,
  86  |         headers: requestHeaders,
  87  |         agent: false,
  88  |       },
  89  |       (res) => {
  90  |         const chunks = [];
  91  |         res.setEncoding('utf8');
  92  |         res.on('data', (chunk) => chunks.push(chunk));
  93  |         res.on('end', () => {
  94  |           resolve({
  95  |             status: Number(res.statusCode || 0),
  96  |             text: chunks.join(''),
  97  |           });
  98  |         });
  99  |       },
  100 |     );
  101 | 
  102 |     req.setTimeout(timeoutMs, () => {
  103 |       req.destroy(new Error(`[Playwright cleanup] El backend tardó más de ${Math.round(timeoutMs / 1000)} segundos en responder.`));
  104 |     });
  105 |     req.on('error', reject);
  106 | 
  107 |     if (payload !== null) req.write(payload);
  108 |     req.end();
  109 |   });
  110 | }
  111 | 
  112 | async function nodeApi(action, { method = 'GET', body = null, query = {}, auth = null } = {}) {
  113 |   const url = new URL(endpoint(action));
  114 |   for (const [key, value] of Object.entries(query)) {
  115 |     if (value !== undefined && value !== null && value !== '') {
  116 |       url.searchParams.set(key, String(value));
  117 |     }
  118 |   }
  119 | 
  120 |   const { sessionKey, token } = auth || authFromStorageFile();
  121 |   const headers = { Accept: 'application/json' };
  122 |   if (sessionKey) headers['X-Session'] = sessionKey;
  123 |   if (token) headers.Authorization = `Bearer ${token}`;
  124 | 
  125 |   const payload = body === null ? null : JSON.stringify(body);
  126 |   if (payload !== null) headers['Content-Type'] = 'application/json';
  127 | 
  128 |   // No usamos fetch/undici acá. En Windows hubo corridas donde, aun con todos
  129 |   // los tests finalizados y el cleanup completado, Node terminaba con
  130 |   // UV_HANDLE_CLOSING al cerrar handles internos de fetch. Una request HTTP(S)
  131 |   // corta, sin keep-alive y con Connection: close evita dejar esos handles
  132 |   // pendientes y mantiene la limpieza fuera del fetch interceptado por Balto.
  133 |   const result = await rawHttpRequest(url, {
  134 |     method,
  135 |     headers,
  136 |     payload,
  137 |     timeoutMs: 120_000,
  138 |   });
  139 | 
  140 |   return normalizeResult(result.status, result.text);
  141 | }
  142 | 
  143 | function assertCleanupResult(result, phase) {
  144 |   if (!result.ok || result.body?.exito === false) {
> 145 |     throw new Error(
      |           ^ Error: [Playwright cleanup] inicio de corrida: HTTP 500. No se pudo completar la limpieza automática del testing.
  146 |       `[Playwright cleanup] ${phase}: HTTP ${result.status}. ${result.body?.mensaje || result.text || 'Falló la limpieza E2E.'}`,
  147 |     );
  148 |   }
  149 | 
  150 |   const remaining = Number(result.body?.restantes_total || 0);
  151 |   if (remaining !== 0) {
  152 |     throw new Error(
  153 |       `[Playwright cleanup] ${phase}: quedaron ${remaining} registro(s) E2E sin eliminar. ` +
  154 |       JSON.stringify(result.body?.restantes || {}),
  155 |     );
  156 |   }
  157 | 
  158 |   const storageErrors = Array.isArray(result.body?.archivos_storage_errores)
  159 |     ? result.body.archivos_storage_errores
  160 |     : [];
  161 |   if (storageErrors.length) {
  162 |     throw new Error(
  163 |       `[Playwright cleanup] ${phase}: la BD quedó limpia, pero ${storageErrors.length} archivo(s) físico(s) no pudieron borrarse. ` +
  164 |       JSON.stringify(storageErrors),
  165 |     );
  166 |   }
  167 | 
  168 |   const deleted = Number(result.body?.eliminados_total || 0);
  169 |   console.log(`[Playwright cleanup] ${phase}: ${deleted} registro(s)/archivo(s) E2E eliminados.`);
  170 |   return result.body;
  171 | }
  172 | 
  173 | function shouldRunCleanup() {
  174 |   return Boolean(ENV.cleanup && ENV.allowMutations);
  175 | }
  176 | 
  177 | export async function cleanupE2EWithPage(page, { scope = 'all', prefix = '', phase = 'inicio' } = {}) {
  178 |   if (!shouldRunCleanup()) return null;
  179 |   assertSafeMutationConfiguration();
  180 | 
  181 |   // IMPORTANTE: no usamos window.fetch de la aplicación. Balto envuelve ese
  182 |   // fetch con un timeout corto para requests de UI y podía abortar una limpieza
  183 |   // legítima antes de que el PHP terminara. Tomamos la autenticación del
  184 |   // storageState del contexto y hacemos la llamada directamente desde Node.
  185 |   const state = await page.context().storageState();
  186 |   const auth = authFromStorageState(state);
  187 |   const result = await nodeApi(CLEANUP_ACTION, {
  188 |     method: 'POST',
  189 |     auth,
  190 |     body: {
  191 |       confirmacion: CONFIRMATION,
  192 |       scope,
  193 |       ...(prefix ? { prefix } : {}),
  194 |     },
  195 |   });
  196 |   return assertCleanupResult(result, phase);
  197 | }
  198 | 
  199 | export async function cleanupE2EFromStorage({ scope = 'prefix', prefix = '', phase = 'fin' } = {}) {
  200 |   if (!shouldRunCleanup()) return null;
  201 |   assertSafeMutationConfiguration();
  202 | 
  203 |   const result = await nodeApi(CLEANUP_ACTION, {
  204 |     method: 'POST',
  205 |     body: {
  206 |       confirmacion: CONFIRMATION,
  207 |       scope,
  208 |       ...(prefix ? { prefix } : {}),
  209 |     },
  210 |   });
  211 |   return assertCleanupResult(result, phase);
  212 | }
  213 | 
  214 | export async function e2eCleanupStatusFromStorage({ scope = 'prefix', prefix = '' } = {}) {
  215 |   if (!shouldRunCleanup()) return null;
  216 |   assertSafeMutationConfiguration();
  217 |   const result = await nodeApi(STATUS_ACTION, {
  218 |     query: { scope, ...(prefix ? { prefix } : {}) },
  219 |   });
  220 |   if (!result.ok || result.body?.exito === false) {
  221 |     throw new Error(
  222 |       `No se pudo consultar el estado de limpieza E2E: HTTP ${result.status}. ${result.body?.mensaje || result.text || ''}`,
  223 |     );
  224 |   }
  225 |   return result.body;
  226 | }
  227 | 
```